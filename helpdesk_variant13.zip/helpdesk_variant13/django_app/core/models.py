from django.db import models
from django.contrib.auth.models import User
class Customer(models.Model):
 user=models.OneToOneField(User,on_delete=models.CASCADE); phone=models.CharField(max_length=30,blank=True)
 def __str__(self): return self.user.username
class Category(models.Model):
 name=models.CharField(max_length=120,unique=True); description=models.TextField(blank=True)
 def __str__(self): return self.name
class Agent(models.Model):
 user=models.OneToOneField(User,on_delete=models.CASCADE); categories=models.ManyToManyField(Category,blank=True); active=models.BooleanField(default=True)
 def __str__(self): return self.user.username
class Priority(models.Model):
 name=models.CharField(max_length=20,unique=True); level=models.PositiveSmallIntegerField(default=1)
 def __str__(self): return self.name
class Tag(models.Model):
 name=models.CharField(max_length=40,unique=True)
 def __str__(self): return self.name
class SLAPolicy(models.Model):
 priority=models.OneToOneField(Priority,on_delete=models.CASCADE); response_minutes=models.PositiveIntegerField(default=60); resolution_minutes=models.PositiveIntegerField(default=1440)
 def __str__(self): return self.priority.name
class Ticket(models.Model):
 STATUS=[('new','Нове'),('working','У роботі'),('waiting','Очікує клієнта'),('resolved','Вирішене'),('closed','Закрите')]
 customer=models.ForeignKey(Customer,on_delete=models.CASCADE,related_name='tickets'); agent=models.ForeignKey(Agent,null=True,blank=True,on_delete=models.SET_NULL,related_name='tickets'); category=models.ForeignKey(Category,null=True,on_delete=models.SET_NULL); priority=models.ForeignKey(Priority,on_delete=models.PROTECT); tags=models.ManyToManyField(Tag,blank=True); title=models.CharField(max_length=200); description=models.TextField(); status=models.CharField(max_length=20,choices=STATUS,default='new'); created_at=models.DateTimeField(auto_now_add=True); deadline=models.DateTimeField(null=True,blank=True); resolved_at=models.DateTimeField(null=True,blank=True)
 def __str__(self): return f'#{self.pk} {self.title}'
class Comment(models.Model):
 ticket=models.ForeignKey(Ticket,on_delete=models.CASCADE,related_name='comments'); author=models.ForeignKey(User,on_delete=models.CASCADE); body=models.TextField(); internal=models.BooleanField(default=False); created_at=models.DateTimeField(auto_now_add=True)
class Attachment(models.Model):
 ticket=models.ForeignKey(Ticket,on_delete=models.CASCADE,related_name='attachments'); file=models.FileField(upload_to='tickets/'); uploaded_by=models.ForeignKey(User,on_delete=models.CASCADE); created_at=models.DateTimeField(auto_now_add=True)
class KnowledgeArticle(models.Model):
 title=models.CharField(max_length=200); body=models.TextField(); category=models.ForeignKey(Category,null=True,blank=True,on_delete=models.SET_NULL); published=models.BooleanField(default=True); created_at=models.DateTimeField(auto_now_add=True)
 def __str__(self): return self.title
class CSAT(models.Model):
 ticket=models.OneToOneField(Ticket,on_delete=models.CASCADE); score=models.PositiveSmallIntegerField(); feedback=models.TextField(blank=True)
